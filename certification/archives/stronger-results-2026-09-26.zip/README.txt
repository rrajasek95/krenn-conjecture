Krenn stronger-results repository certification — 26 September 2026

Audited payload commit: b2ea434a1fa9ba9c08ae524268a69a1e7ed388bb
Payload manifest SHA-256: 17f127b063e844a100e68c4a6463dd323f1e94dbc48d3a4a92e56dae79b8a940

Start with certification/stronger-results-2026-09-26/README.md and THEOREMS.md.
The independent admission audit is certification/audits/SUPERSESSION-2026-09-26-01.md.
The admission record is at the end of certification/SUPERSESSIONS.md.
Historical ledger entries and copied proof notes retain some external links;
all load-bearing proof and audit texts are mapped locally in THEOREMS.md.

From the extracted archive root, using Python 3.10+ and no dependencies:
  python3 certification/stronger-results-2026-09-26/verify.py
  python3 -O certification/stronger-results-2026-09-26/verify.py
  python3 -I -S certification/stronger-results-2026-09-26/verify.py
  python3 certification/audits/SUPERSESSION-2026-09-26-01-check.py

The first three commands reproduce the identical saved replay JSON. The
fourth is the auditor's independently implemented permutation and polynomial
checker. Certification also relies on the written analytic proofs and their
independent audit; these bounded checks are not an all-order formal proof.

Certified scope: original-basis global diagonality; strict color-degree
restrictions; general complex eight- and ten-site nonexistence. The four-site
example is preserved. Lean verification and general even orders >=12 remain
open under this package. No complete-conjecture claim is made.
